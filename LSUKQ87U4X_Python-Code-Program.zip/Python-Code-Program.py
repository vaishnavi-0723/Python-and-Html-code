# calculation with python
m=20
n=10
print(m+n)
print(m-n)
print(m*n)
print(m/n)
print(m%n)

print("_ "*30)

# Relational operaters
m=20
n=15
print(m>n)
print(m<n)
print(m>=n)
print(m<=n)
print(m!=n)

print("_ "*30)

# string indexing

word="vaishnavi"
length=len(word)
print("output: "+word[0])
print("output: "+word[length-1])
print("output: "+word[int(length/2):])

print("_ "*30)

# string Repitation
n="word"
print("output: "+n*5)

print("_ "*30)


# string concatination

name="vaishu"
print("output: "+"*"*3+name+"*"*3)

print("_ "*30)

#using conditional statement
n=50
if n%2==0:
    print("output: "+"even")
else:
    print("output: "+"odd")
    
    
print("_ "*30)

#greater Number
m=20
n=30
s=15
if m>n:
    greater_number=m
else:
    greater_number=n
if n>greater_number:
    greater_number=s
print(greater_number)


print("_ "*30)


#printing Armstrong Number
n="371"
first_number=int(n[0])**3
second_number=int(n[1])**3
third_number=int(n[2])**3
armstrong_number=first_number+second_number+third_number==n
print("output: "+str(armstrong_number))

print("_ "*30)

#printing the n numbers using while loop
n=10
count=1
while count<n:
    print(count)
    count=count+1


print("_ "*30)

#printing two right angled triangles using while loop 
n=4
count=0
while count<n:
    count=count+1
    print(str(count)*count)
    
print("_ "*30)

#priting the characters using for loop

n="Vaishnavi"
for i in n:
    print(i)
    
print("_ "*30)

# reversing the string using for loop
n="vaishnavi"
reverse=""
for i in n:
    reverse=i+reverse
print(reverse)

print("_ "*30)
    
#printing even numbers
n=20
result=""
for i in range(1,n+1):
    if i%2==0:
        result=result+str(i)+" "
print(result)

#printing odd numbers
n=30
result=""
for i in range(1,n+1):
    if i%2==1:
      result=result+str(i)+" "
print(result)

#printing prime numbers
n = 20
string = ""
for i in range(2,n+1):
    factors = 0 
    for j in range(2,i):
        if i % j == 0:
            factors = factors + 1 
    if factors == 0:
        string = string + str(i) + " "
print("Output: "+ str(string))


print("_ "*30)

#printing M pattern with python
n=5
for i in range(1,n+1):
    stars="* "*i
    space=4*(n-i)
    row=stars+" "*(space)+stars
    print(row)
    
print("_ "*30)

#Pring Inverted Right angled triangle

n=5
for i in range(0,n):
    star="* "*(n-i)
    space=" "*(2*(i))
    row=space+star
    print(row)
    
print("_ "*30)

#printing Hollow butterfly
n=3
for i in range(1,n+1):
    if i==1 or i==2:
        stars="* "*i
        space="  "*(2*(n-i))
        row=stars+space+stars
    else:
        row="* "+"  "*(i-2)+"* "+"  "*(2*(n-i))+"* "+"  "*(i-2)+"* "
    print(row)
for i in range(1,n+1):
    if i<n:
       h_space="  "*((n-1)-i)
       mid_space="  "*(2*(i-1))
       row="* "+h_space+"* "+mid_space+"* "+h_space+"*"
    else:
        if i==n:
          row="*     "+mid_space+"* "
    print(row)
    
print("_ "*30)

#string methods
name=" Vaishnavi "
print(name.upper()) #converting string to Uppercase Letters
print(name.lower()) #converting string to lowercase letters
print(name.strip(" "))#Removing lead or trailing spaces

url="https://google.cam"
print(url.startswith("https"))
print(url.endswith(".com"))
print(url.replace("cam","com"))

print("_ "*30)

#palindrom

n="madam"
reverse=""
for i in n:
    reverse=i+reverse
if reverse==n:
    print("output: "+"palindrom")
    

print("_ "*30)

#printing alphabets using Unicode values
result=""
for i in range(65,91):
    result=result+str(chr(i))
print(result)
result=""
for i in range(97,123):
    result=result+str(chr(i))
print(result)
result=""
for i in range(48,58):
    result=result+str(chr(i))
print(result)